
import UIKit

class ViewController: UIViewController , UITextFieldDelegate{
    @IBOutlet weak var fonclima: UIImageView!
    @IBOutlet weak var temperaturalbl: UILabel!
    @IBOutlet weak var imagenclima: UIImageView!
    @IBOutlet weak var mensajetemplbl: UILabel!
    @IBOutlet weak var nombreCiudadTf: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        fonclima.image = UIImage(named: "Nublado")
        nombreCiudadTf.delegate = self
        
    }

    @IBAction func bucarBtn(_ sender: UIButton) {
        print(nombreCiudadTf.text ?? "No hay nada que buscar")
    }
    
    @IBAction func ubicacionBtn(_ sender: UIButton) {
        print("Se obtuvo gps")
    }
    
    /////////////////////metodos de ui text field
    //boton de buscar presionado
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        print("boton presionado")
        
        return true
    }
    
    //el usuario acabo de editar
    func textFieldDidEndEditing(_ textField: UITextField) {
        print("el usuario termino de editar")
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if nombreCiudadTf.text != ""{
            return true
        }else{
            print("necesitas escribir una ciudad")
            return false
        }
    }
}

//https://api.openweathermap.org/data/2.5/weather?q=London&appid=fb540c21323ed122505ce242df21b704&units=metric&lang=es


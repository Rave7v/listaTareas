//
//  Pregunta.swift
//  quizz app
//
//  Created by Mac12 on 08/03/22.
//

import Foundation

struct Pregunta {
    let texto: String
    let respuesta: String
}
